"""Immutable F-study source/model/protocol and substage boundary."""
from pathlib import Path
from .limited_prediction import read,sha,need

BASE='39d06ce5edb4dc7f7fff18bedc76909350a946d4'


def verify_identity(path,required,scope):
    identity=read(path);root=Path(identity['source_root']);manifest=read(Path(identity['bound_inputs']['source_manifest']))
    need(identity['baseline']==BASE and root.resolve()==Path(__file__).resolve().parents[2],'Actual F imported source/baseline')
    indexed={v['path']:v['sha256'] for v in identity['artifacts']}
    need(len(indexed)==len(identity['artifacts']) and set(identity['bound_inputs'].values())<=set(indexed),'Unique complete frozen inputs')
    for key,value in required.items():need(str(Path(value).resolve())==identity['bound_inputs'][key],'Actual F arguments/weights/input paths bound')
    for name in ('src','scripts','tests'):
        for file in (root/name).rglob('*.py'):
            relative=file.relative_to(root).as_posix()
            need(str(file.resolve()) in indexed and relative in manifest['files'] and sha(file)==manifest['files'][relative]['sha256'],'Every executed source/test equals reviewed archive')
    for file,digest in indexed.items():need(sha(Path(file))==digest,'F source/input/model bytes unchanged')
    review=read(Path(identity['bound_inputs']['review']));gate=read(Path(identity['bound_inputs']['gate']))
    need(review['approved'] and scope in review['approved_scopes'],'Independent review authorizes this F substage')
    need(review['source_archive_SHA256']==manifest['sha256']==sha(Path(identity['bound_inputs']['source_archive'])),'Actual reviewed archive bytes')
    for name,digest in review['reviewed_input_SHA256'].items():need(sha(Path(identity['bound_inputs'][name]))==digest,'Reviewed study/case/input matches actual runtime')
    need(gate['success'] and not(gate['errors'] or gate['failures'] or gate['skipped']) and gate['tests']>=329,'Real full329Torch plus F tests execution gate')
    needed={'tests/test_timing_skill.py','tests/test_timing_semantics.py','tests/test_timing_skill_features.py'}
    need(gate['source_root']==str(root) and set(gate['F_test_sources'])==needed and len(set(gate['F_test_ids']))>=12,'Actual F test modules executed at reviewed source')
    for name,digest in gate['F_test_sources'].items():need(sha(root/name)==digest,'Actual F test sources match gate')
    return identity
