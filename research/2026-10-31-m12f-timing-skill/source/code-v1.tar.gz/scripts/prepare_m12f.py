"""Freeze bounded F0/F1/F2 design and new confirmation identities before calls."""
import hashlib
import json
from pathlib import Path
import subprocess

from patrol_rsi.timing_skill import TimingSkill,NUMERIC_DOMAINS,BOOL_FIELDS,MARGIN_COEFFICIENTS,information_baseline

ROOT=Path(__file__).resolve().parents[1]
STAGE=ROOT/'research/2026-10-31-m12f-timing-skill'
OLD=ROOT/'research/2026-10-31-m12e-timing-schema'
BASE='39d06ce5edb4dc7f7fff18bedc76909350a946d4'
REMOTE_OLD='/share/home/renly/renly-patrol-rsi/runs/20261031-m12e'
FIXTURES=(('healthy',900),('coldplate_fouling',180),('dc_contact_hotspot',180),('sensor_bias',900),('aux_feeder_loss+cdu_fouling',180))


def read(p):return json.loads(p.read_bytes())
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')


def main():
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
    known=[]
    for seed in (33000,33001):
        complete=read(OLD/'evidence/run/E1'/f'seed-{seed}/complete.json');seen=set()
        for ordinal in range(18):
            diag=complete['diagnostics'][ordinal];spec=diag['specification'];key=spec['scenario'],spec['noise_c']
            if key in seen:continue
            seen.add(key);folder=OLD/'evidence/run/E1'/f'seed-{seed}'
            old=next(v for v in complete['rows'] if v['episode_purpose']=='main' and v['method']=='evidence_gate_urgency' and v['specification']==spec)
            release=read(folder/'public-release'/f'condition-{ordinal:02d}--public-selections-release.json')
            physical='--'.join(str(spec[k]) for k in ('seed','scenario','duration_s','fault_start_s'))
            source_meta=folder/'sources'/physical/'complete.json'
            known.append({'case_id':f'known-{seed}-{ordinal:02d}','partition':'F1_development_known','specification':spec,
                'trace_folder':f'{REMOTE_OLD}/E1/seed-{seed}/sources/{physical}','source_meta_SHA256':sha(source_meta),
                'trace_file_SHA256':read(source_meta)['trace_file_SHA256'],'process_fingerprint':diag['process_fingerprint'],
                'reference_E1_action_SHA256':release['all5_actual_action_log_SHA256']['evidence_gate_urgency'],
                'reference_E1_metrics':old['metrics'],'original_development_seen':True})
    assert len(known)==20
    future=[]
    splits={'F1_validation':[35020,35021],'F1_final':[35040,35041,35042,35043],
        'F2_meta':[36000,36001],'F2_adapt':[36100,36101],'F2_validation':[36120,36121],'F2_final':[36140,36141,36142,36143]}
    for phase,seeds in splits.items():
        for seed in seeds:
            for family,duration in FIXTURES:
                pool=[v for v in range(95,900,5) if v not in (150,335,520,705)]
                number=int(hashlib.sha256(f'M12F-phase-v1|{phase}|{seed}|{family}'.encode()).hexdigest(),16);onset=pool[number%len(pool)]
                for noise in (.2,1.):
                    spec={'phase':phase,'seed':seed,'scenario':family,'duration_s':duration,'fault_start_s':onset,'noise_c':noise,
                        'estimator':'history','control':'feedback','resources':'provisioned','variant':'open'}
                    future.append({'case_id':f'{phase}-{seed}-{family}-{noise}','partition':phase,'specification':spec,'planned_not_generated':True})
    write(STAGE/'cases-v1.json',{'baseline':BASE,'known_development':known,'future':future,'new_phase_rule':'SHA256 namespace M12F-phase-v1, partition/seed/family; fixed5sgrid95..895 excludingold4; no phase value to policy or prompts.'})
    refs1=['Tour','human_professional','initial_E1_skill','manual_information','simple3','prior3','experienced3','experienced3_PPOtool']
    refs2=['Tour','human_professional','initial_E1_skill','manual_information','simple8','prior3','fixed_experience3','fixed_experience8','meta3','meta3_PPOtool']
    protocol={'protocol':'M12F-TimingSkill-Study-v1','baseline':BASE,'status':'frozen_for_independent_review_before_calls','cases_SHA256':sha(STAGE/'cases-v1.json'),
        'goal':'Separately test taskincrement, causal-public-experience-plus-feedback treatment, and improver-method transfer; no PPO/prediction superiority universal prerequisite.',
        'historical_boundaries':'M12D/M12E/oldE2 source/results/models/tests unchanged; oldE2NO-GO. Only knownE1development reread, never oldprivatefinal. No1280process rebuild/no newneuraltraining/no24callformatrerun.',
        'safety_core':['originalM9physics','18heterogeneousqualifiedownedexecutors','route/service/access','oneglobalCHECK','fixed60scooldownstudycontract','originalfullreturn','originaleffectivequalifiedmeasurement','exactinitial-terminalrevisit','hiddenlabelsandfinalaccess'],
        'skill_space':{'language':'TimingSkill-v1','OR_rules_max':3,'AND_predicates_each_max':6,'depth':2,'numeric_domains':{k:list(v) for k,v in NUMERIC_DOMAINS.items()},
            'boolean_fields':sorted(BOOL_FIELDS),'special_margin_coefficients':list(MARGIN_COEFFICIENTS),'default':'CONTINUE_TOUR',
            'semantics':'Rules admit CHECK over raw hard-legal EXTRA candidates. No initialE1heuristic outsideSkill. AnyFALSE/unknown predicate blocksitsAND;None not0/normal. Sharedrotation firstadmittedagent, rankurgent unlessfrozenPPOtoolcontrast.',
            'initial_skill':TimingSkill.initial_e1().to_dict(),'manual_information_skill':information_baseline().to_dict(),
            'not_editable':'No arbitrary code/taskIDs/absoluteclock/seed/faultphase/labels, no kernel/model/evaluator/budget modification; rankingtool fixedoutsidegeneratedskill.',
            'known_alarm_semantics':'No compulsoryalarmveto in safetycore. If checking knownpublicalarm labelrecheck; evaluatorcountsfirstconfirmationperphysicalsegment once, publicnewalert/persistent/recovery separately. No firstdiscoverycreditfromduplicateknownconfirmation.'},
        'F0':{'semantic_regressions':'Actualobserver+measured_anomaly qualifiedpositive/recovery coupling; originalevaluate_episode repeatedalarm sameevent onlyonce.',
            'same_input_parity':'InitialAST vsunchangedE1gate onallarchivedE1publiccandidateinputs andactualCHECKpublicsnapshots. Preserveold source, not rerunformat or infercausalnewgain.',
            'closed_loop_parity':'Runinitialskillon20knowncases; canonicalactionhash andoriginalmetrics equalE1urgency (excludingdecisionCPU/inferencetime). Source/pureoutputrecorder mayaddmetadata, not semantic changes.',
            'engineering_environment_cap':20,'new_physical_processes':0,'GPU':0,'LLM_calls':0,'cost_profile':'ActualinitialsameinterpreterCPUtime beforeGPUlaunch; profileuncertainty disclosed, no outcome-basedbudget adjustment.'},
        'F1':{'generation_repeats':[9801,9802,9803],'development':'known20cases,firstoriginalmanifestphaseperfamily; not independentnewtask evidence',
            'independent_validation':'35020/35021,5physicalprocesses/seed2noises; allskillsselectedbeforegeneration',
            'final':'35040..35043,onlyifF1validationgate below passes; one opening',
            'groups':{'simple_search':{'slots':3,'model_calls':0},'prior_only':{'slots':3,'model_calls':3},'experienced_fixed':{'slots':3,'model_calls':3}},
            'references':refs1,'PPO_tool_control':'EXACTexperiencedselectedskill withPPOinsteadurgent. No additionalproposal or best-toolselection; secondarytoolcausalcontrast, never anentrygate.',
            'treatment':'Sameinitialparent EVERYslot/bothLLMgroups; samecommon system/schema/featuresemantics/example, matchedgenerationseeds/order. Ownpast2proposalJSON/schema-errors allowedboth. PriorgetsNOtrajectory/metrics/selected-parent/acceptancebits. Experiencedgets causalpubliccards+allowedaccept/rejectbits. Contrast is combinedexperience+feedback package, not isolatedrawtrajectory effect.',
            'seed_formula':{'LLM_both_groups':'g*10000+100+s,s0..2','simple':'g*10000+200+s,s0..2'},
            'model_order':'For eachrepeat andslot: priorcall thenexperiencedcall; evaluation feedback onlytoexperienced nextprompt; no extra generationretry.',
            'nominal_per_repeat_environment_caps':{'development':280,'validation':160,'final':320,'total':760},'all3_nominal_environment_cap':2280,
            'fixed_reference_identity':'initial_E1_skill IS exactTimingSkill.initial_e1/urgent, sharedstartbaseline, not a distinctlegacyexecutor. Tour=emptyTimingSkill/urgent;manualinformation=declaredAST/urgent;human usesoriginalhumanexecutor. Cacheincludes executor+ranker+skill+semantic_source+models+cases.',
            'cache_scope':'Oneimmutableevaluatorcache perpartition,sharedallgroupsANDgenerationrepeats; searchhistory/cardsnotshared. Prioronlygetsownqueryneutralstatus, never cachedothergrouphistory. No cachecrosspartitions.',
            'strict_actual_bound_including_F0':'Sharedfixedrefs give dev<=680unique (4fixed*20+27candidate*20+3PPOcontrols*20),val<=320,final<=640. PlusF0engineering20 <=1660, safelywithin2280cap. No free unchargedparityexecutions.'},
        'F2':{'entry':'F0allchecks AND explicitmechanism_gate below AND actualresource/sourcechecks. NOT F1positive/PPOsuperiority/probabilityprerequisite. F1negative preserved; F2newpreplannedhypothesis/newpartitions, no F1taskprogram orconfirmationhistorytransfer.',
            'generation_repeats':[9901,9902,9903],'partitions':'F2_meta36000/1;adapt36100/1;validation36120/1;final36140..43.5processes/seed2noise.',
            'per_repeat':{'fixed_experience_slots':8,'fixed_prefix3_saved':True,'meta_protocol_attempts':1,'old_inner_slots':2,'new_inner_slots':2,'fresh_meta_slots':3,'prior_only_slots':3,'simple_slots':8,'model_call_cap':19},
            'meta_sequence':'Runincumbent2first;proposeprotocolusingonlycompletedinitial/incumbentpubliccards+acceptbits;candidate2fromsameinitial/emptyhistory withmatchedseeds. Retainonlyifstrictlybetter fixedhierarchicaldevelopmentkey+safety. Invalidprotocol=incumbentclone,still2candidate slots,norepair/resample.',
            'protocol_container':'ReuseControlledImprover/Improver;allowedwrite diagnostics1..3/order,memory,3fixedinstructiontemplates,generatorqwen_once/random_program,dedupexact_version/canonical_rule_order. Acceptancefixedstrict_improvement,failurefixedkeep_parent; rejectotherchanges. NewTimingSkillproposalwrapper,notoldPatrolProgramparser.',
            'transfer':'Onlyschema-validatedretainedprotocol; taskskillinitialE1,experience/history/proposalarchive/outcomes/cache reset fornewadapt. Evaluationcacheemptyonceperpartition,sharedinsideold/new/searchgroups,never acrosspartitions.',
            'references':refs2,'primary':'Meta fresh3 versusfixedprefix3, samefreshproposalopportunities; fullmeta preparation up to5calls+env separatelycharged. Fixed8secondarysame8callcapbutmorefreshopportunities;prior3/random8/strongmanualcontrols retained.',
            'PPO_tool_control':'ExactfrozenmetaselectedskillwithPPO ranker; no reselection,secondarynot gate.',
            'seed_formula':{'old_new_inner':'g*10000+1000+s,s0..1 identical','protocol':'g*10000+2000','fixed8_meta3':'g*10000+3000+s,fixeds0..7,metas0..2','prior3':'g*10000+4000+s','simple8':'g*10000+5000+s'},
            'per_repeat_environment_caps':{'meta':100,'adapt':540,'validation':200,'final':400,'total':1240},'all3_environment_cap':3720,'all3_model_call_cap':57,
            'cache_identity':'Partition/repeat-scopedimmutableevaluationstore;exactsource/weights/noise/cases+executor+ranker+skill. InitialreferenceisSkillinitialnotlegacyE1alias; originalhumanmodeunique. SamePGdifferentranker/mode MUSTNOTcollide.'},
        'mechanism_gate':{'F0_pass':True,'per_each_F1_repeat_prior_valid_min':2,'per_each_F1_repeat_experienced_valid_min':2,'out_of_slots':3,
            'per_each_F1_repeat_experienced_behavior_changed_min':1,
            'behavior':'Bothsame-inputpublicprobe decisiondifference and at least1actualcanonicalactiontrajectorySHA difference versusinitialonknowncases; excludeCPU/inferencetime/JSONexplanation. Syntax-onlydifference insufficient.',
            'public_feedback':'Atleast1actionable causalsnapshot->lateractualqualifiedmeasurement card inEACH4professions; timestampsordered,existingchannels/provenance, promptforbiddenfieldszero.',
            'safety':'Allactualpoliciespass originalqualification/quota/fullreturn/initial-tail/externalmeasurement; anyruntime/source/safetyfailure stops, not a performancefailure.'},
        'random_sampler':'np.default_rng(candidate_seed); rulescountuniform0..3;eachANDcountuniform1..6;fieldsfromsortedregisteredfields+evidence_margin;chooseoperator/valueuniformfromexactfielddomain,includingexplicitmissingness. AlwaysparsewithsameTimingSkillvalidator; duplicates/contradictions/no-opconsumeoriginalslot,noresampling.',
        'experience_retrieval':'Whitelisted5diagnosticfamiliescoverage/professional_evidence/efficiency/thermal_disagreement/novelty;memorynone/recent/best_and_failures. Poolonlyowncompletedprogramruns+initialbaseline. Selectpublicobservedalert/normalcontrast perprofession,breaktiesbyknownmeasurementage/time/task;nothiddeneventeligibility. Atmost8cards/twoownpreviousprograms. Dropendcardsdeterministicallyiftokencap,neverschema/parent;recordtruncation. No hiddenlabels/scores/Oracle/onsets/scenarios/seeds/oldfinal inprompts.',
        'public_feedback_limit':'Accept/rejectbit allowedexperienced/metaonly. No numericmiss/censoredwait/hiddenrankinglabel inprompt. Schemaerrorsownoutput allowedall; newalert,persistentrecheck,recovery andactualschedulecost arepublic.',
        'evaluation':{'unit':'Meanpairednoise/process,then equal5physicalprocesses/seed,then equalseeds. Waitwithincondition originalconsequenceweightedcensor; onlyeventbearingprocesses waitdefined; healthyretainedincost/miss/safety.3modelrepeats reuse2val/4finalseedgroups,not6/12independentenvironments.',
            'inner_selection':'Samehierarchicalmacroasconfirmation. Candidateeligibleiffallknown-devseedmiss<=initialseedmiss andsafety;chooselexicographic(macro_miss,macro_wait,meanCHECK,meanwalk). Strictlybetterarchivegetsacceptedbit; initialparentremainsconstantinprompts.',
            'strict_gain':'Forallconfirmationseedsmiss_candidate<=baseline AND (macro_misslower OR(samemiss AND relativewaitgain>=5%) OR(samemiss ANDsamewait ANDCHECKmean>=5%lower ANDwalknotincrease)). Cost-onlygainlabelledas such, never anomalyclaim.',
            'nonregression':'Forallseedsmiss<=baseline AND(macro_misslower OR(samemiss ANDmacro_wait<=baselinewait)). No positivegainrequirement here.',
            'F1_TaskGO':'StrictgainversusTour,human_professional,initial_E1_skill,manual_information,simple3 inEVERY3repeat;allsource/safety/resourcegates.',
            'F1_ExperienceGO':'Strictgainversusprior3 inEVERY3repeat ANDnonregressionversusTour/human/initial/manual inEVERYrepeat. Claimonlycombinedexperience+acceptancefeedbackeffect.',
            'F1_final_open':'All3developmentselectedmappingsfrozen beforevalidationgeneration;validationTaskGO ORExperienceGO plusallsafety/source/resourcechecks ->onefinalopenforall8refs. OtherwiseF1finalsealed,reportnegative;no reselection.',
            'F2_MetaGO':'Strictgainmeta3versusfixed3 inEVERY3repeat ANDnonregressionversusTour/human/initial/manual/simple8;allsource/safety/resourcechecks. Fixed8secondaryreported.',
            'F2_final_open':'All3searches+validationselected9/10policySpecssealed;MetaGOvalidationpass andsource/safety/resource ->onefinalopenforall10refs. Failurefinalsealed. No Tourmaskingperformance,reselectionorrerescore.',
            'confirmation':'Finalmust independentlyrepeattherelevantGOformula;reporttask,experience,meta separately. No poolingevents/noise/modelrepeatsasindependentrooms. Smallpilotpointgatesnotpopulationguarantee.'},
        'resources':{'all_real_model_calls_cap':75,'F1_model_calls_cap':18,'F2_model_calls_cap':57,'input_per_call':6144,'output_per_call':1024,'per_call_timeout_s':90,
            'GPU_allocations_cap':4,'GPU_minutes_each_cap':90,'GPU_total_seconds_cap':21600,'GPU_soft_stop_s':5280,'GPU_type':'oneV100S32GB4gpu','CPU_each_GPU':4,'RAM_GPU_GB':48,
            'CPU_job_cores':2,'CPU_RAM_GB':8,'CPU_job_minutes_cap':60,'max_compute_allocations_parallel':2,'allocated_CPU_minutes_total_cap':2400,'all_environment_attempts_cap':6000,'new_storage_bytes_cap':6000000000,
            'accounting':'Chargebeforeallattempts;actual+cachehits+logicalreferences separately. AllSlurmstartup/modelverify/load/inference/env/auditincluded. Unknownfailedoutputtokenscharge1024upperbound,notzero. Runtime/source/safetyfailstops,norescueallocation/freecalls.'},
        'execution_gate':'No realcall/newconfirmationphysics until independent protocol/source review,fullrealTorchgate,newsource+weight+case+promptidentity andactualSlurmscript verifiedwhileheld. F0CPUknownparityscope separatelyreviewed. No new24callpreflight; firsttaskcallsarechargedsearchslots.'}
    write(STAGE/'M12F-Study-v1.json',protocol)
    files=subprocess.check_output(['git','ls-files','-z']).decode().split('\0');old={}
    for name in filter(None,files):p=ROOT/name;old[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
    write(STAGE/'evidence/protected-baseline.json',{'baseline':BASE,'files':old})
    print('M12F_DESIGN_BEFORE_CALLS',len(known),len(future),len(old),sha(STAGE/'M12F-Study-v1.json'),flush=True)


if __name__=='__main__':main()
