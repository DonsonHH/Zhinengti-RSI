from types import SimpleNamespace
import unittest

import numpy as np

from patrol_rsi.limited_prediction import COL,expanded_features,scalar_score,view_indices
from patrol_rsi.limited_metrics import evaluate,fpr_threshold,probabilities,weighted_ap


class LimitedPredictionTests(unittest.TestCase):
    def public(self):
        x=np.zeros((4,98),np.float32);x[:,COL['root_time_s']]=[30,60,90,120];x[:,COL['pod']]=[0,1,2,3]
        return x

    def test_time_view_cannot_observe_state_or_CVAE_channels(self):
        x=self.public();first=expanded_features(x,'time_lr','thermal')
        x[:,COL['temperature_measurement.value']]=100;x[:,COL['cvae_raw.value']]=999
        x[:,COL['already_measured_alarm']]=1;x[:,COL['public_primary_supply_c']]=300
        self.assertTrue(np.array_equal(first,expanded_features(x,'time_lr','thermal')))
        self.assertFalse(np.array_equal(expanded_features(x,'public_lr','thermal'),expanded_features(self.public(),'public_lr','thermal')))

    def test_CVAE_views_are_exactly_separate_and_thermal_only(self):
        base=view_indices('public_lr','thermal');raw=view_indices('public_raw_lr','thermal')
        cache=view_indices('public_assimilated_lr','thermal');both=view_indices('public_all_lr','thermal')
        self.assertEqual((len(raw)-len(base),len(cache)-len(base),len(both)-len(base)),(6,6,12))
        self.assertNotIn(COL['history_assimilated.value'],raw)
        self.assertNotIn(COL['cvae_raw.value'],cache)
        with self.assertRaises(ValueError):view_indices('public_all_lr','electrical')
        with self.assertRaises(ValueError):scalar_score(self.public(),'frozen_CVAE_raw','control')

    def test_missing_measurement_is_not_a_real_normal_observation(self):
        x=self.public();x[:,COL['contact.value']]=90
        self.assertTrue((scalar_score(x,'professional_hold','electrical')==0).all())
        x[:,COL['contact.available']]=1
        self.assertTrue((scalar_score(x,'professional_hold','electrical')==1).all())

    def test_tied_constant_AUPRC_equals_weighted_prevalence(self):
        y=np.array([1,0,0,1]);w=np.array([.1,.2,.3,.4]);p=np.full(4,.2)
        self.assertAlmostEqual(weighted_ap(y,p,w),.5)
        result=probabilities(y,p,w)
        self.assertAlmostEqual(result['Brier'],.34)
        self.assertAlmostEqual(sum(v['weight'] for v in result['reliability_bins']),1.)

    def test_1percent_threshold_conservatively_rejects_ties(self):
        y=np.zeros(100,int);p=np.r_[np.ones(3),np.zeros(97)]
        threshold=fpr_threshold(y,p)
        self.assertEqual(threshold,1.)
        self.assertEqual(int((p>threshold).sum()),0)

    def test_invalid_B_minus_one_cannot_enter_probability_metrics(self):
        with self.assertRaises(ValueError):probabilities(np.array([-1,0,1]),np.array([.1,.1,.8]),np.ones(3))

    def cohort(self):
        y=np.array([0,0,0,0,1,1,1,1],np.int8)
        m=np.zeros((8,8),np.int32);m[:,2]=np.repeat(range(4),2);m[:,3]=20000;m[:,4]=[0,0,0,0,1,1,1,1]
        m[:,5]=[0,0,0,0,11,11,11,11];m[:,1]=1;m[:,7]=[60,90]*4
        return SimpleNamespace(n=8,y=np.column_stack((y,y)),w=np.full(8,1/8),meta=m)

    def test_noise_event_and_zero_event_denominators(self):
        data=self.cohort();p=np.array([.1,.1,.1,.1,.9,.1,.9,.1])
        result=evaluate(data,1,p,.5)
        self.assertEqual(result['summary']['unique_eligible_events'],1)
        self.assertEqual(result['summary']['seed_macro_event_recall'],1.)
        self.assertEqual(result['seeds'][0]['event_eligible_processes'],1)
        self.assertEqual(result['seeds'][0]['numeric_processes'],2)
        self.assertEqual(result['summary']['samples'],8)

    def test_noise_eligibility_mismatch_stops_instead_of_dropping_noise(self):
        data=self.cohort();data.y[6:,1]=0
        with self.assertRaisesRegex(ValueError,'Paired noise eligibility'):
            evaluate(data,1,np.full(8,.1),.5)


if __name__=='__main__':unittest.main()
