import importlib.util
import unittest

import numpy as np


@unittest.skipUnless(importlib.util.find_spec('torch') is not None,'Torch unavailable in lightweight host')
class LimitedModelTorchTests(unittest.TestCase):
    def data(self,batch):
        from patrol_rsi.limited_prediction import COL
        class Fixture:
            def batches(self,batch_rows=16384):
                for start in range(0,self.n,batch):
                    end=min(self.n,start+batch);yield slice(start,end),self.x[start:end],self.w[start:end],self.y[start:end]
        d=Fixture();d.n=64;d.x=np.zeros((64,98),np.float32)
        d.x[:,COL['root_time_s']]=np.tile([30,60,90,120],16);d.x[:,COL['pod']]=np.arange(64)%16
        d.x[:,COL['temperature_measurement.value']]=np.linspace(40,80,64)
        d.x[:,COL['temperature_measurement.available']]=1
        target=(np.arange(64)>31).astype(np.int8);d.y=np.column_stack((target,target));d.w=np.full(64,1/64)
        return d

    def test_streamed_gradient_fit_matches_single_batch_fit(self):
        from patrol_rsi.limited_model import fit_lr,lr_scores
        a=self.data(8);b=self.data(64)
        ma=fit_lr(a,'public_lr','thermal',1,.1);mb=fit_lr(b,'public_lr','thermal',1,.1)
        self.assertEqual(ma['status'],'completed_within_fixed_optimizer_budget')
        self.assertEqual(mb['status'],'completed_within_fixed_optimizer_budget')
        np.testing.assert_allclose(lr_scores(a,ma),lr_scores(b,mb),atol=2e-6,rtol=2e-6)
        self.assertLessEqual(ma['closure_evaluations'],400)
        self.assertTrue(ma['no_full_float64_design_matrix'])

    def test_calibration_is_monotone_finite_and_bounded_budget(self):
        from patrol_rsi.limited_model import fit_calibrator,calibrated
        scores=np.linspace(-2,2,64);y=(scores>0).astype(np.int8);w=np.ones(64)
        c=fit_calibrator(scores,y,w);self.assertEqual(c['status'],'completed_within_fixed_optimizer_budget')
        p=calibrated(scores,c);self.assertTrue((np.diff(p)>=0).all())
        self.assertTrue(np.isfinite(p).all());self.assertLessEqual(c['closure_evaluations'],300)


if __name__=='__main__':unittest.main()
